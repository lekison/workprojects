package com.example.e_comerce

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
